﻿using System;

namespace B
{
    public
    static class taskB
    {
        private static string function(this string str)
        {
            if (str.Length == 0)
                System.Console.WriteLine("Error");

            Char[] ch = str.ToCharArray();

            for (int i = 0; i < ch.Length; i ++)
            {
                if (Char.IsLetter(ch[i]))
                {
                    if (i % 2 == 0)
                        ch[i] = Char.ToUpper(ch[i]);

                    else
                        ch[i] = Char.ToLower(ch[i]);
                }
                else
                    ch[i] = '.';
            }
            return new string(ch);
        }

        static void Main(string[] args)
        {
            var str = "hello@#!$%^&*()_ world!".function();

            Console.WriteLine(str);
        }
    }
}
