﻿using System;

namespace A
{
    class mixedNumber
    {
        int num, den, integer;
        static int ctr = 0;
    

        public int Numerator
        {
            set { num = Math.Abs(value); }
            get { return num; }
        }
        
        public int Denominator
        {
            set { den = Math.Abs(value); }
            get { return den; }
        }

        public mixedNumber(int a, int num, int denom)
        {
            integer = a;
            Numerator = num;
            Denominator = denom;
        }
        
        public mixedNumber(int num, int denom):this(0, num, denom)
        {
        }

        public mixedNumber(int a)
        { integer = a; }

        public static int gcd(int numA, int numB)
        {
            int remainder = 0;

            while (numB != 0)
            {
                remainder = numA % numB;
                numA = numB;
                numB = remainder;
            }
            return numA;
        }

        public (int, int) simp()
        {
            int gcd_ab = gcd(Numerator, Denominator);
           
            Numerator = Numerator / gcd_ab;
           
            Denominator = Denominator / gcd_ab;
            
            ctr += 1;

            return (Numerator, Denominator);
        }

        public  static mixedNumber operator + (mixedNumber a, mixedNumber b)
        {
            int aNum = ((a.integer * a.Denominator) + a.Numerator);
            
            int aDenom = a.Denominator;

            int bNum = ((b.integer * b.Denominator) + b.Numerator);
            
            int bDenom = b.Denominator;

            int temp = gcd(aDenom, bDenom);

            int numerator = aNum * (bDenom / temp) + bNum * (aDenom / temp);
         
            int denominator = aDenom * (bDenom / temp);

            int num = numerator / denominator;

            int rem = numerator % denominator;
            
            ctr += 1;

            return new mixedNumber(num, rem, denominator);
        }

        public  double ToDouble()
        { return Numerator / (double)Denominator; }

        public int getctr()
        { return ctr; }

        public string ToString()
        {
            return integer.ToString() + " " + Numerator.ToString() + " " +
                   Denominator.ToString();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            mixedNumber aVar = new mixedNumber(1, 5, 25);

            mixedNumber bVar = new mixedNumber(1, 10, 20);

            mixedNumber ans = aVar + bVar;
            ans.simp();

            Console.WriteLine(ans.ToString());

            Console.WriteLine(ans.ToDouble());
        }
    }
}
