﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using Xceed.Wpf.Toolkit;

namespace main
{
    public class FileException : Exception
    {
        public FileException(Exception e)
            : base(e.Message, e.InnerException)
        {
        }
    }

    class Program
    {
        public static void PrintWordCountsInFile(string fileName)
        {
            if (fileName is null)
            {
                Console.WriteLine("You did not supply a file path.");
                
                return;
            }

            try
            {
                var text = System.IO.File.ReadAllText(fileName);
             
                var words = SplitWords(text);

                var counts = CountWordOccurrences(words);

                WriteWordCounts(counts, System.Console.Out);
            }

            catch (ArgumentException e)
            {
                Console.WriteLine("One of the arguments provided to a method is not valid.");
                throw new FileException(e);
            }
            catch (PathTooLongException e)
            {
                Console.WriteLine("The path or fully qualified file name is longer than the system-defined maximum length.");
                throw new FileException(e);
            }
            catch (DirectoryNotFoundException e)
            {
                Console.WriteLine("The part of a file or directory cannot be found.");
                throw new FileException(e);
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine("An attempt to access a file that does not exist on disk fails.");
                throw new FileException(e);
            }
        }
     
        public static IEnumerable<string> SplitWords(string text)
        {
            Regex wordMatcher = new Regex(@"\p{L}+");
           
            return wordMatcher.Matches(text).Select(c => c.Value);
        }

        public static IDictionary<string, int> CountWordOccurrences(IEnumerable<string> words)
        {
            return CountOccurrences(words, StringComparer.CurrentCultureIgnoreCase);
        }

        public static void WriteWordCounts(IDictionary<string, int> counts, TextWriter writer)
        {

            int k = 0;

            var items = from pair in counts
                        orderby pair.Value descending
                        select pair;

            writer.WriteLine("The number of counts for each words are:");
          
            foreach (KeyValuePair<string, int> kvp in items)
            {
                writer.WriteLine("Counts: " + kvp.Key.ToLower() + " => " + kvp.Value);

                k++; 
                
                if (k == 10) return;
            }
        }

        public static IDictionary<T, int> CountOccurrences<T>(IEnumerable<T> items, IEqualityComparer<T> comparer)
        {
            var counts = new Dictionary<T, int>(comparer);

            foreach (T t in items)
            {
                int count;
                if (!counts.TryGetValue(t, out count))
                {
                    count = 0;
                }
                counts[t] = count + 1;
            }
            return counts;
        }
        static void Main(string[] args)
        {
            System.Net.WebClient wc = new System.Net.WebClient();

            string source = @"C:\Users\aimanov\Desktop\07-Imanov-Aykhan\main\mainsddddddddddddddddddddddddffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff\log.txt";
            
            try
            {
                byte[] raw = wc.DownloadData("http://norvig.com/big.txt");

                string webData = System.Text.Encoding.UTF8.GetString(raw);

                webData = webData.ToLower();

                File.WriteAllText(source, webData);

                PrintWordCountsInFile(source);
            }

            catch (WebException e)
            {
                Console.WriteLine("Couldn't connect to the URL address...");
                throw new FileException(e);
            }
        }
    }
}
