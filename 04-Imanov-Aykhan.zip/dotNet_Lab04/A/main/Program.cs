﻿using System;

namespace main
{
    class Program
    {

        public static Tuple<int, int> GetFromConsoleXY(ref string firstComment, ref string secondComment)
        {
            System.Console.Write(firstComment);

            int x = Convert.ToInt32(Console.ReadLine());


            System.Console.Write(secondComment);

            int y = Convert.ToInt32(Console.ReadLine());


            firstComment = Convert.ToString(x);

            secondComment = Convert.ToString(y);


            return Tuple.Create(x, y);
        }
        static void Main(string[] args)
        {
            string txtFirst = "Read the first text: ";

            string txtSecond = "Read the second text: ";


            System.Console.WriteLine(GetFromConsoleXY(ref txtFirst, ref txtSecond));

            System.Console.Write(txtFirst + " " + txtSecond);

        }
    }
}
