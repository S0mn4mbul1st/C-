﻿using System;

namespace C
{
    class Program
    {
        public static void CountMyTypes()
        {

        }

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
