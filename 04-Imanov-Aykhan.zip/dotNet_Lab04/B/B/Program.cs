﻿using System;
using System.Xml.Schema;

namespace B
{
    class Program
    {
        public static void DrawCard(string fLine, string sLine, char ch, int x, int size)
        {
            bool check = false; 
            for(int j = 0; j < x; j++)
                 for (int i = 1; i <= size; i++)
                  {
                       Console.Write(ch);

                        if (i % size == 0) Console.WriteLine();
                  }

            for(int i = 0; i < size; i ++)
            {

                if ((i < x) || (i > (size - x)))

                    Console.Write(ch);

                else if ( (size - fLine.Length - x ) /2 >= i)

                    Console.Write(' ');

                else if ( (i < (size - x ) ) && check )
                    Console.Write(' ');

                else if (i >= (size - x ) )

                    Console.Write(ch);

                else
                {
                    Console.Write(fLine);

                    check = true;

                    i += fLine.Length - 1;
                }
            }

            Console.WriteLine();

            check = false;

            for (int i = 0; i < size; i++)
            {

                if ((i <x) || (i > (size - x)))

                    Console.Write(ch);

                else if ((size - sLine.Length - x) / 2 >= i)

                    Console.Write(' ');

                else if ((i < (size - x)) && check)
                    Console.Write(' ');

                else if (i >= (size - x))

                    Console.Write(ch);
                  

                else
                {
                    Console.Write(sLine);

                    check = true;

                    i += sLine.Length - 1;
                }
            }

            Console.WriteLine();
            for (int j = 0; j < x; j++)
                for (int i = 1; i <= size; i++)
                 {
                Console.Write(ch);

                if (i % size == 0) Console.WriteLine();
                  }
        }
        static void Main(string[] args)
        {
            DrawCard("Aykhan", "Imanov", 'X', 3, 20);
        }
    }
}
