﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Lab_11.DataContext;
using Lab_11.ViewModels;


namespace Lab_11.Controllers
{
    public class UserController : Controller
    {
        private Data _dataContext;

        public UserController(Data dataContext){
            this._dataContext = dataContext;
        }

        public ActionResult Index(){
            return View(_dataContext.GetUsers());
        }

        public ActionResult Details(string email){
            return View(_dataContext.GetUser(email));
        }

        public ActionResult Create(){
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(UserViewModel user){
            try{
                if (ModelState.IsValid)
                    _dataContext.AddUser(user);
               
                return RedirectToAction(nameof(Index));
            }
            catch{
                return View();
            }
        }

        public ActionResult Edit(string email){
            return View(_dataContext.GetUser(email));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(string email, UserViewModel user){
            try
            {
                if (ModelState.IsValid)
                {
                    user.email = email;
                    _dataContext.UpdatedUser(user);
                }
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Delete(string email){
            return View(_dataContext.GetUser(email));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(string email, IFormCollection collection) {
            try{
                _dataContext.RemoveUser(email);
               
                return RedirectToAction(nameof(Index));
            }
            catch{
                return View();
            }
        }
    }
}
