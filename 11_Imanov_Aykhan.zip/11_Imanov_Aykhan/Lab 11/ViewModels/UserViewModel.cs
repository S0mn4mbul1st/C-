﻿using System.ComponentModel.DataAnnotations;

namespace Lab_11.ViewModels
{
    public enum Category {tester, developer}
    public class UserViewModel
    {
        public UserViewModel()
        {}

        [Required]
        [RegularExpression(@"^\S+@\S+$", ErrorMessage = "Error, Mail address is invalid!")]
        [MaxLength(40, ErrorMessage = " Error, The maximum allowed character amount is 40, over length")]
        public string email { get; set; }
        [Required]
        [RegularExpression(@"^[0-9]{5}(?:-[0-9]{4})?$", ErrorMessage = "Error, Invalid Post Code is decleared")]
        public string zipCode { get; set; }
        public Category category { get; set; }

        public UserViewModel(string email, string zip, Category category){
            this.email = email;
            this.zipCode = zip;
            this.category = category;
        }
    }
}
