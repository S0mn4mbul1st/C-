﻿using System.Collections.Generic;
using Lab_11.ViewModels;

namespace Lab_11.DataContext
{
    public interface Data
    {
        List<UserViewModel> GetUsers();
        UserViewModel GetUser(string email);
        void AddUser(UserViewModel user);
        void RemoveUser(string email);
        void UpdatedUser(UserViewModel user);
    }
}
