﻿using System.Collections.Generic;
using System.Linq;
using Lab_11.ViewModels;

namespace Lab_11.DataContext
{
    public class BackEnd : Data
    {
        Dictionary<string, UserViewModel> users = new Dictionary<string, UserViewModel>();

        public void AddUser(UserViewModel user){
            if (!users.ContainsKey(user.email)){
                users.Add(user.email, user);
            }
        }

        public UserViewModel GetUser(string email){
            return users[email];
        }

        public void RemoveUser(string email){
            users.Remove(email);
        }

        public void UpdatedUser(UserViewModel user){   
            if (users.ContainsKey(user.email))   
                users[user.email] = user;
            
            else
                users.Add(user.email, user);
        }

        public List<UserViewModel> GetUsers(){
            return users.Values.ToList();
        }
    }
}
