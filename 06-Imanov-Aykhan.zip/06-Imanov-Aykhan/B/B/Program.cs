﻿using System;

namespace B
{
    interface IFigure
    {
        public void MoveTo(double x, double y);

        string colour { set; get; }
    }

    interface IHasInterior
    {
        string colour { set; get; }
    }

    public class Employee : IFigure
    {
        double a, b;

        public string colour
        {
            get { return colour; }
            set { colour = value; }
        }

        void IFigure.MoveTo(double x, double y)
        {
            a = x;
            b = y;
        }
    }

    public class Student : IHasInterior, IFigure
    {
        double a, b;

        public string colour
        {
            get { return colour; }
            set { colour = value; }
        }

        public void MoveTo(double x, double y)
        {
            a = x;
            b = y;
        }
    }

    class Program
    {
        public static void checker(Object[] arr)
        {
            foreach(Object data in arr)
            {
                if (data is IHasInterior)
                    Console.WriteLine(data);
                else 
                    Console.WriteLine("No Colour");
            }
        }

        static void Main(string[] args)
        {
            Object[] obj = new Object[6];

            obj[0] = new Employee();
            obj[1] = new Student();
            obj[2] = new Employee();
            obj[3] = new Employee();
            obj[4] = new Object();
            obj[5] = new Student();

            checker(obj);
        }
    }
}
