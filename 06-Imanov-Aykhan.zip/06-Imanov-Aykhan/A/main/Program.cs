﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace main
{
    abstract class Vehicle
    {
        string brand;
        string model;
        private double capacity;

        //public abstract void ToString();
        public void setCapacity(double num)
        {
            capacity = num;
        }
        public double loadCapacity()
        {
            return capacity;
        }
    }

    class motoVehicle: Vehicle
    {
        string motorType;

        public override string ToString()
        {
            return("This is called from MotoVehicle class");
        }
    }

    class bicycle : Vehicle
    {
        string wheelType;

        public override string ToString()
        {
            return ("This is called from Bicyle class");
        }
    }

    class car : Vehicle
    {
        int freePlaces;

        public override string ToString()
        {
            return("This is called from Car class");
        }
    }

    class truck : Vehicle
    {
        int backwardSize;

        public override string ToString()
        {
            return("This is called from Truck class");
        }
    }

    class Program
    {   

        public static string totCapacity(Vehicle[] obj)
        {
            double ans = 0;

            for (int i = 0; i < obj.Length; ++ i)
            {
                if (obj[i].loadCapacity() is double)
                {
                    ans += obj[i].loadCapacity();
                }
            }
            return("\nTotal Capacity:" + ans);
        }

        static void Main()
        {
            Vehicle[] obj = new Vehicle[4];

            obj[0] = new truck();
            obj[0].setCapacity(1);

            obj[1] = new car();
            obj[1].setCapacity(1);

            obj[2] = new bicycle();
            obj[2].setCapacity(1);

            obj[3] = new motoVehicle();
            obj[3].setCapacity(1);

            totCapacity(obj);

           System.Console.WriteLine(obj[0].ToString());
           System.Console.WriteLine(obj[1].ToString());
           System.Console.WriteLine(obj[2].ToString());
           System.Console.WriteLine(obj[3].ToString());

            System.Console.ReadLine();
        }
    }
}
